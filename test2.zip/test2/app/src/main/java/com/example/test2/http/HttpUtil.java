package com.example.test2.http;

import com.example.test2.bean.User;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;


public class HttpUtil {
   public void loginWithOkHttp(String address, User user,okhttp3.Callback callback){
       MediaType JSON = MediaType.parse("application/json; charset=utf-8");
        OkHttpClient client = new OkHttpClient();
       ObjectMapper mapper=new ObjectMapper();
       try {
           String jacksonString = mapper.writeValueAsString(user);
           Request request = new Request.Builder()
                   .url(address)
                   .post(RequestBody.create(JSON,jacksonString))
                   .build();

           client.newCall(request).enqueue(callback);
       }
       catch (Exception e)
       {
           e.printStackTrace();
       }


    }
    //注册
    public void registerWithOkHttp(String address,String account,String password,okhttp3.Callback callback){
        OkHttpClient client = new OkHttpClient();
        RequestBody body = new FormBody.Builder()
                .add("username",account)
                .add("password",password)
                .build();
        Request request = new Request.Builder()
                .url(address)
                .post(body)
                .build();
        client.newCall(request).enqueue(callback);
    }

}
