package com.example.test2.util;
import android.util.Log;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
public class JacksonUtil {
    static ObjectMapper mapper = new ObjectMapper();
    public static <T> T deserialize(String json,Class<T> cls){
        T t = null;
        try{
            t=mapper.readValue(json, cls);
        }catch (Exception ex){
            return null;
        }
        return t;
    }

    public static <T> List<T> decode(String json, Class<T> cls) {
        List<T> list=new ArrayList<>(  );
        try{
            mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            mapper.configure( DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true) ;
            mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
            JavaType javaType = mapper.getTypeFactory().constructParametricType(List.class, cls);
            list=mapper.readValue(json, javaType);
        }
        catch (Exception ex){
            Log.e( "listerror",ex.toString() );
            return null;
        }
        return list;
    }

    public <T> String mapToJson(Map<T,T> map){
        String json="";
        try {
            json = mapper.writeValueAsString(map);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }
}
